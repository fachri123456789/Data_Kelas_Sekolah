<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Kelas extends Model
{
    use HasFactory;

    // Tentukan nama tabel jika tidak sesuai dengan nama default (kelas)
    protected $table = 'kelas';

    // Tentukan kolom yang dapat diisi secara massal
    protected $fillable = [
        'name',
        'description',
    ];

    // Jika ingin menetapkan kolom yang tidak boleh diisi secara massal
    // protected $guarded = ['id'];

    // Tentukan kolom timestamps jika menggunakan waktu created_at dan updated_at
    public $timestamps = true;
}
