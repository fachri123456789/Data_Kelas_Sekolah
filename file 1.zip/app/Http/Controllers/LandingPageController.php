<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LandingPageController extends Controller
{
    public function index()
    {
        return view('landing'); // Mengarahkan ke resources/views/landing.blade.php
    }
}
