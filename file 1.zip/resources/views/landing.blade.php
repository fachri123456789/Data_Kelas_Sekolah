@extends('layouts.app')
@section('content')
    <!-- Slider Section -->
    <section id="slider" class="bg-primary text-white py-5">
        <div class="container text-center">
            <h2 class="mb-4">Selamat Datang Di Kelas Saya</h2>
            <div id="carouselExample" class="carousel slide">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <div class="d-flex justify-content-center align-items-center bg-secondary text-white" style="height: 200px;">
                            <h3>Wali Kelas Bernana Bayu </h3>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="d-flex justify-content-center align-items-center bg-dark text-white" style="height: 200px;">
                            <h3>Kelas III C</h3>
                        </div>
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section id="features" class="py-5">
        <div class="container text-center">
            <h2 class="mb-4">Fitur Utama</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">Jumlah Siswa</h5>
                            <p class="card-text">Kelas saya terdapat 20 siswa laki-laki dan 10 siswa perempuan.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">Ketua Kelas</h5>
                            <p class="card-text">Ketua kelas saya bernama Fachri</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">Wakil Ketua Kelas</h5>
                            <p class="card-text">Wakil ketua kelas saya bernama Ferdi</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Call to Action Section -->
    <section id="cta" class="bg-light py-5">
        <div class="container text-center">
            <h2 class="mb-3">Kembali Ke Atas </h2>
            <p class="mb-4">Silahkan kembali ke atas jika sudah selesai</p>
            <a href="#" class="btn btn-primary btn-lg">Mulai Sekarang</a>
        </div>
    </section>
@endsection
