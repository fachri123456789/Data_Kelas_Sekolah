@extends('layouts.app')

@section('title', 'Add New Kelas')

@section('header', 'Add New Kelas')

@section('content')
    <h2>Form to Add New Kelas</h2>

    <form action="{{ route('kelas.store') }}" method="POST">
        @csrf
        <div class="mb-3">
            <label for="name" class="form-label">Class Name</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <input type="text" class="form-control" id="description" name="description" required>
        </div>
        <button type="submit" class="btn btn-success">Save</button>
    </form>
@endsection
