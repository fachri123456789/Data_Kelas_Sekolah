@extends('layouts.app')

@section('title', 'Data Kelas')

@section('header', 'Data Kelas')

@section('content')
    <h2>Welcome to the Kelas Page</h2>
    <p>This page contains information about classes.</p>

    <a href="{{ route('kelas.create') }}" class="btn btn-primary">Add New Class</a>

    <table class="table mt-3">
        <thead>
            <tr>
                <th>Name</th>
                <th>Description</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($kelas as $k)
                <tr>
                    <td>{{ $k->name }}</td>
                    <td>{{ $k->description }}</td>
                    <td>
                        <a href="{{ route('kelas.edit', $k) }}" class="btn btn-warning">Edit</a>
                        <form action="{{ route('kelas.destroy', $k) }}" method="POST" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endsection
