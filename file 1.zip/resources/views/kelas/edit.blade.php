@extends('layouts.app')

@section('title', 'Edit Kelas')

@section('header', 'Edit Kelas')

@section('content')
    <h2>Form to Edit Kelas</h2>

    <form action="{{ route('kelas.update', $kelas) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="mb-3">
            <label for="name" class="form-label">Class Name</label>
            <input type="text" class="form-control" id="name" name="name" value="{{ $kelas->name }}" required>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <input type="text" class="form-control" id="description" name="description" value="{{ $kelas->description }}" required>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
@endsection
