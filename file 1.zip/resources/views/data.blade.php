@extends('layouts.app')

@section('title', 'Data Page')

@section('header', 'Data Page')

@section('content')
    <h2>Welcome to the Data Page</h2>
    <p>This page contains information about data.</p>
    <!-- You can add actual data here -->
@endsection
