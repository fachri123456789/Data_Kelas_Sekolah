<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LandingPageController;
use App\Http\Controllers\DataController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\KelasController;
// Rute menuju LandingPageController
Route::get('/', [LandingPageController::class, 'index']);

Route::get('/data', [DataController::class, 'index']);
Route::get('/profil', [ProfileController::class, 'index']);

Route::resource('kelas', KelasController::class);
Route::put('/kelas{kelas}', [KelasController::class, 'kelas.update']);
