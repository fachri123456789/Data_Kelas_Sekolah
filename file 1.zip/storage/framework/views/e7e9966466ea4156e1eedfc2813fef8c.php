

<?php $__env->startSection('title', 'Profile Page'); ?>

<?php $__env->startSection('header', 'Profile Page'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Selamat Datang di Kelas Mawar </h2>
    <p>Kelas Mawar adalah sebuah ruang pembelajaran yang dirancang untuk memberikan pengalaman edukatif yang menyeluruh dan menyenangkan. Di kelas ini, peserta akan mendapatkan pemahaman mendalam tentang bahasa Inggris, matematika, pengembangan diri. Kami mengutamakan pendekatan yang interaktif dan berbasis pada pengalaman nyata untuk memastikan setiap peserta dapat menguasai materi dengan cara yang lebih aplikatif dan menyenangkan.

Dengan pengajaran yang didukung oleh metode yang terstruktur, materi yang relevan, serta penggunaan teknologi terkini, kelas ini bertujuan untuk mengasah kemampuan peserta dalam berkomunikasi dengan percaya diri dalam bahasa Inggris, memahami konsep matematika secara mendalam. Kami juga mendorong kerja sama antar peserta melalui diskusi, tugas kelompok, dan proyek praktis, agar tercipta suasana belajar yang kolaboratif dan mendukung pertumbuhan pribadi.

Tidak hanya teori, di kelas ini Anda akan dihadapkan pada berbagai simulasi, latihan, dan tantangan yang dirancang untuk memperkaya pengalaman belajar serta mengasah keterampilan praktis. Setiap peserta akan dibimbing oleh pengajar yang berkompeten dan berpengalaman di bidangnya, dengan perhatian khusus untuk setiap perkembangan individu.

Bergabunglah dengan kelas Mawar dan tingkatkan kemampuan Anda bersama kami!</p>
    <!-- You can add profile details here -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\landing-page\resources\views/profil.blade.php ENDPATH**/ ?>