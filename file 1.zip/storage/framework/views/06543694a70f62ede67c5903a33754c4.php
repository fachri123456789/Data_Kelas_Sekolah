    
<?php $__env->startSection('content'); ?>
    <section id="slider" class="bg-light py-5">
        <div class="container">
            <h2>Slider</h2>
            <div id="carouselExample" class="carousel slide">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="/images/banner1.jpg" class="d-block w-100" alt="...">
                    </div>
                    <div class="carousel-item">
                        <img src="/images/banner2.jpg" class="d-block w-100" alt="...">
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
        </div>
    </section>
    <section id="features" class="py-5">
        <div class="container">
            <h2>Fitur Utama</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Fitur 1</h5>
                            <p class="card-text">Deskripsi fitur 1.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Tambahkan section lainnya seperti Tentang, Call to Action, FAQ -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\landing-page\resources\views//landing.blade.php ENDPATH**/ ?>