

<?php $__env->startSection('title', 'Data Page'); ?>

<?php $__env->startSection('header', 'Data Page'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Welcome to the Data Page</h2>
    <p>This page contains information about data.</p>
    <!-- You can add actual data here -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\landing-page\resources\views/data.blade.php ENDPATH**/ ?>