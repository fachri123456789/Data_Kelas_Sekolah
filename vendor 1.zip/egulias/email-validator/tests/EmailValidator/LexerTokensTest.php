<?php

namespace Egulias\EmailValidator\Tests\EmailValidator;

use PHPUnit\Framework\TestCase;

class LexerTokensTest extends TestCase
{
    public function testToken()
    {
        $this->markTestIncomplete("implement better lexer tokens");
    }
}
