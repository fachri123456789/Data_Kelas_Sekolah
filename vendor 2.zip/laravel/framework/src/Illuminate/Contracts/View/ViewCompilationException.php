<?php

namespace Illuminate\Contracts\View;

use Exception;

class ViewCompilationException extends Exception
{
    //
}
